//
//  AppDelegate.h
//  CreateGifImages
//
//  Created by user on 22/02/16.
//  Copyright © 2016 Qburst. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

